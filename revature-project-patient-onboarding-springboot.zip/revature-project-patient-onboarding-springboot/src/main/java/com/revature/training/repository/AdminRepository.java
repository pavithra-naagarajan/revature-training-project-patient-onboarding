
  package com.revature.training.repository;
  
  import org.springframework.data.repository.CrudRepository;
  
  import com.revature.training.model.Admin;
  
  public interface AdminRepository extends CrudRepository<Admin, Integer> {
  
  }
 
